
<?php $__env->startSection('content'); ?>
<div class="features_items"><!--features_items-->
    <?php
    $keyw = session()->get('keyword');
    if($keyw){
        echo '<h2 class="title text-center">Sản phẩm liên quan đến "'.$keyw.'"</h2>';
    }
    ?>
    <?php $__currentLoopData = $search_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item =>$product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
    <div class="col-sm-3 product-main">
        <div class="product-image-wrapper">
            <div class="single-products">
                <div class="productinfo">
                    <form>
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" value="<?php echo e($product->product_quantity); ?>" class="check_product_qty_<?php echo e($product->product_id); ?>">

                        <input type="hidden" value="<?php echo e($product->product_id); ?>" class="cart_product_id_<?php echo e($product->product_id); ?>">
                        <input type="hidden" value="<?php echo e($product->product_name); ?>" class="cart_product_name_<?php echo e($product->product_id); ?>">
                        <input type="hidden" value="<?php echo e($product->product_img); ?>" class="cart_product_image_<?php echo e($product->product_id); ?>">
                        <input type="hidden" value="<?php echo e($product->product_desc); ?>" class="cart_product_desc_<?php echo e($product->product_id); ?>">
                        <input type="hidden" value="<?php echo e($product->product_price); ?>" class="cart_product_price_<?php echo e($product->product_id); ?>">
                        <input type="hidden" value="1" class="cart_product_qty_<?php echo e($product->product_id); ?>">


                        <a href="<?php echo e(URL::to('chi-tiet-san-pham/'.$product->product_id)); ?>" class="link-product-details">
                        </a>
                        <img src="<?php echo e(URL::to('public/upload/product/'.$product->product_img)); ?>" alt="" />
                        <div class="product-info-details">
                            <p><?php echo e($product->product_name); ?></p>
                            <div class="product-price-sold">
                                <span class="product-price"><?php echo e(number_format($product->product_price,0,',','.')); ?>.đ</span>
                                <span class="product-sold">Đã bán 100</span>
                            </div>
                            <div class="product-rate-cart">
                                <div class="product-rate">
                                    <img style="width:75%; margin-top:0" src="<?php echo e(asset('public/front-end/images/product-details/rating.png')); ?>" alt=""/>
                                    <span style="color: #ccc; margin-left:4px">10</span>
                                </div>
                                <button type="button" class="btn btn-default add-to-cart" data-id_product="<?php echo e($product->product_id); ?>" name="add-to-cart"><i class="fa-solid fa-cart-plus"></i></button>
                            </div>
                        </div>

                        

                    </form>
                </div>

            </div>
            <div class="choose">
                <ul class="nav nav-pills nav-justified">
                    
                    <li><a href="#" ><i class="fa-regular fa-heart like-product"></i>Yêu thích</a></li>
                    <li><a href="#" class=""><i class="fa-solid fa-down-left-and-up-right-to-center" style="color: rgb(115, 115, 241)"></i>So sánh</a></li>
                </ul>
            </div>
        </div>
        <div class="items-overlay"></div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
</div><!--product body-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\nien-luan-b1706621\resources\views/pages/product/search.blade.php ENDPATH**/ ?>