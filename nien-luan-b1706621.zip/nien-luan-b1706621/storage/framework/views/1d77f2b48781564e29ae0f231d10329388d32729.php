
<?php $__env->startSection('admin_content'); ?>

<div class="table-agile-info">
    <div class="panel panel-default">
        <div class="panel-heading">
            Danh sách các thương hiệu
        </div>
        <div class="row w3-res-tb">
            <div class="col-sm-5 m-b-xs">
                <select class="input-sm form-control w-sm inline v-middle">
                    <option value="0">Bulk action</option>
                    <option value="1">Delete selected</option>
                    <option value="2">Bulk edit</option>
                    <option value="3">Export</option>
                </select>
                <button class="btn btn-sm btn-default">Apply</button>                
            </div>
            <div class="col-sm-4">
            </div>
            <div class="col-sm-3">
                <div class="input-group">
                    <input type="text" class="input-sm form-control" placeholder="Search">
                    <span class="input-group-btn">
                        <button class="btn btn-sm btn-default" type="button">Go!</button>
                    </span>
                </div>
            </div>
        </div>
        <div class="table-responsive">
            <table class="table table-striped b-t b-light">
                <?php
                    $message = Session::get('message');
                    if($message){
                        echo  $message;
                        session()->put('message', null);
                    }
                ?>
            <thead>
                <tr>
                <th style="width:20px;">
                    <label class="i-checks m-b-none">
                    <input type="checkbox"><i></i>
                    </label>
                </th>
                <th>STT</th>
                <th>Tên thương hiệu</th>
                <th>LOGO thương hiệu</th>
                <th>Ẩn/Hiện</th>
                <th>Ngày thêm</th>
                <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $all_brand_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cate_pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr>
                    <td><label class="i-checks m-b-none text-"><input type="checkbox" name="post[]"><i></i></label></td>
                    <td><?php echo e($cate_pro->brand_id); ?></td>
                    <td><?php echo e($cate_pro->brand_name); ?></td>
                    <td><img src="<?php echo e(asset('public/upload/product/'.$cate_pro->brand_image)); ?>" height="30" width="100"></td>
                    <td><span class="text-ellipsis">
                        <?php
                        if($cate_pro->brand_status == 0){
                        ?>
                            <a style="font-weight: 600" href="<?php echo e(URL::to("/unactive-brand-product/".$cate_pro->brand_id)); ?>">Ẩn</a>
                        <?php
                        }else {
                        ?>
                            <a style="font-weight: 600" href="<?php echo e(URL::to("/active-brand-product/".$cate_pro->brand_id)); ?>">Hiện</a>
                        <?php
                        }
                        ?>    
                    </span></td>
                    <td><span class="text-ellipsis"><?php echo e($cate_pro->created_at); ?></span></td>
                    <td>
                        <a href="<?php echo e(URL::to('/edit-brand-product/'.$cate_pro->brand_id)); ?>" class="active link-icon-category" ui-toggle-class=""><i class="fa fa-pencil-square-o"></i></a> |
                        <a href="<?php echo e(URL::to('/delete-brand-product/'.$cate_pro->brand_id)); ?>" onclick="return confirm('Bạn có chắc là xóa danh mục này?')" class="active link-icon-category" ui-toggle-class=""><i class="fa fa-times text-danger"></i></a>
                        
                    </td>
                </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            </table>
        </div>
    <footer class="panel-footer">
        <div class="row">
          
          <div class="col-sm-5 text-center">
            <small class="text-muted inline m-t-sm m-b-sm">showing 20-30 of 50 items</small>
          </div>
          <div class="col-sm-7 text-right text-center-xs">                
            <ul class="pagination pagination-sm m-t-none m-b-none">
              <li><a href=""><i class="fa fa-chevron-left"></i></a></li>
              <li><a href="">1</a></li>
              <li><a href="">2</a></li>
              <li><a href="">3</a></li>
              <li><a href="">4</a></li>
              <li><a href=""><i class="fa fa-chevron-right"></i></a></li>
            </ul>
          </div>
        </div>
    </footer>
    </div>
  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\tieu-luan\resources\views/admin/all_brand_product.blade.php ENDPATH**/ ?>