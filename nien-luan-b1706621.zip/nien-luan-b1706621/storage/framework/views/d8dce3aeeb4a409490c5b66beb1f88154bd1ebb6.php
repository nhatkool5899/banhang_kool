
<?php $__env->startSection('content'); ?>
<?php $__currentLoopData = $product_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item => $pd_details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="product-details"><!--product-details-->
    
    <div id="fb-root"></div>
    <script async defer crossorigin="anonymous" src="https://connect.facebook.net/vi_VN/sdk.js#xfbml=1&version=v13.0" nonce="uOv3RWts"></script>

    <div class="col-sm-5">
        <div class="view-product">
            <img src="<?php echo e(URL::to('public/upload/product/'.$pd_details->product_img)); ?>" alt="<?php echo e($pd_details->product_img); ?>" />
        </div>
        <div id="similar-product" class="carousel slide" data-ride="carousel">
            
              <!-- Wrapper for slides -->
                <div class="carousel-inner">
                    <div class="item active">
                      <a href=""><img src="<?php echo e(asset('public/front-end/images/product-details/similar1.jpg')); ?>" alt=""></a>
                      <a href=""><img src="<?php echo e(asset('public/front-end/images/product-details/similar2.jpg')); ?>" alt=""></a>
                      <a href=""><img src="<?php echo e(asset('public/front-end/images/product-details/similar3.jpg')); ?>" alt=""></a>
                    </div>
                    <div class="item">
                      <a href=""><img src="<?php echo e(asset('public/front-end/images/product-details/similar1.jpg')); ?>" alt=""></a>
                      <a href=""><img src="<?php echo e(asset('public/front-end/images/product-details/similar2.jpg')); ?>" alt=""></a>
                      <a href=""><img src="<?php echo e(asset('public/front-end/images/product-details/similar3.jpg')); ?>" alt=""></a>
                    </div>
                    <div class="item">
                      <a href=""><img src="<?php echo e(asset('public/front-end/images/product-details/similar1.jpg')); ?>" alt=""></a>
                      <a href=""><img src="<?php echo e(asset('public/front-end/images/product-details/similar2.jpg')); ?>" alt=""></a>
                      <a href=""><img src="<?php echo e(asset('public/front-end/images/product-details/similar3.jpg')); ?>" alt=""></a>
                    </div>
                    
                </div>

              <!-- Controls -->
              <a class="left item-control" href="#similar-product" data-slide="prev">
                <i class="fa fa-angle-left"></i>
              </a>
              <a class="right item-control" href="#similar-product" data-slide="next">
                <i class="fa fa-angle-right"></i>
              </a>
        </div>

    </div>
  
    <div class="col-sm-7">
        <div class="product-information"><!--/product-information-->
            <img src="<?php echo e(asset('public/front-end/images/product-details/new.jpg')); ?>" class="newarrival" alt="" />
            <h2><?php echo e($pd_details->product_name); ?></h2>
            <p>Mã SP: <?php echo e($pd_details->product_id); ?></p>
            <img src="<?php echo e(asset('public/front-end/images/product-details/rating.png')); ?>" alt="" />
            <form>
                <?php echo e(csrf_field()); ?>

                <input type="hidden" value="<?php echo e($pd_details->product_quantity); ?>" class="check_product_qty_<?php echo e($pd_details->product_id); ?>">

                <input type="hidden" value="<?php echo e($pd_details->product_id); ?>" class="cart_product_id_<?php echo e($pd_details->product_id); ?>">
                <input type="hidden" value="<?php echo e($pd_details->product_name); ?>" class="cart_product_name_<?php echo e($pd_details->product_id); ?>">
                <input type="hidden" value="<?php echo e($pd_details->product_img); ?>" class="cart_product_image_<?php echo e($pd_details->product_id); ?>">
                <input type="hidden" value="<?php echo e($pd_details->product_desc); ?>" class="cart_product_desc_<?php echo e($pd_details->product_id); ?>">
                <input type="hidden" value="<?php echo e($pd_details->product_price); ?>" class="cart_product_price_<?php echo e($pd_details->product_id); ?>">
                    
                <span>
                    <span><?php echo e(number_format($pd_details->product_price)); ?> VND</span>
                    <label>Số lượng:</label>
                    <input type="number" class="cart_product_qty_<?php echo e($pd_details->product_id); ?>" name="quantity" value="1" min="1"/>
                </span>
                <button type="button" class="btn btn-default add-to-cart" data-id_product="<?php echo e($pd_details->product_id); ?>" name="add-to-cart" style="margin-bottom: 10px;display:block">
                    <i class="fa fa-shopping-cart"></i>
                    Add to cart
                </button>

            </form>

            <p><b>Màn hình:</b> IPS LCD6.1"Liquid Retina</p>
            <p><b>Hệ điều hành:</b> IOS 15</p>
            <p><b>Thương hiệu:</b> <?php echo e($pd_details->brand_name); ?></p>
            <p><b>Danh mục:</b> <?php echo e($pd_details->category_name); ?></p>
            <a href=""><img src="<?php echo e(asset('public/front-end/images/product-details/share.png')); ?>" class="share img-responsive"  alt="" /></a>
        </div><!--/product-information-->
    </div>
</div><!--/product-details-->

<div class="category-tab"><!--category-tab-->
    <div class="col-sm-12">
        <ul class="nav nav-tabs">
            <li class="active"><a href="#details-pd" data-toggle="tab">Chi tiết sản phẩm</a></li>
            <li><a href="#comment" data-toggle="tab">Bình luận</a></li>
            <li class=""><a href="#reviews" data-toggle="tab">Đánh giá</a></li>
        </ul>
    </div>
    <div class="tab-content">
        <div class="tab-pane fade active in" id="details-pd" >
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p>
            <p><b>Write Your Review</b></p>
            <p><?php echo $pd_details->product_content; ?>p>
        </div>
        
        <div class="tab-pane fade" id="comment" >
            <input type="hidden" value="<?php echo e($pd_details->product_id); ?>" class="comment_product_id">
            
            <form class="col-sm-12">
                <?php echo e(csrf_field()); ?>

                <label class="col-sm-2 control-label">Bình luận:</label>
                <div class="col-sm-6">
                    <textarea style="resize: none" class="form-control add_comment" name="add_comment" id="" cols="30" rows="5" placeholder="Nhập vào bình luận..."></textarea>
                </div>
                <div class="col-sm-2 col-sm-offset-6">
                    <input type="button" id="submit_comment" class="btn btn-primary pull-right" value="GỬI" style="padding: 6px 26px; margin-top:10px">
                </div>
            </form>

            <h4 style="margin: 10px;">Tất cả bình luận</h4>
            <div class="comment-body" id="comment_show" style="margin-bottom:50px">

            </div>


            
            
            
        </div>

        <div class="tab-pane fade" id="reviews" >
            <div class="col-sm-12">
                <ul>
                    <li><a href=""><i class="fa fa-user"></i>EUGEN</a></li>
                    <li><a href=""><i class="fa fa-clock-o"></i>12:41 PM</a></li>
                    <li><a href=""><i class="fa fa-calendar-o"></i>31 DEC 2014</a></li>
                </ul>
                <div class="rating-body">
                    <form>
                        <?php echo e(csrf_field()); ?>

                        <h4 class="title-rating">Đánh giá ngay:</h4>
                        <ul class="list-inline rating" id="rating" title="Average Rating">
                            <?php for($i = 1; $i <= 5; $i++): ?>
                                <?php
                                    if($i < $rating){
                                        $color ='color:#ffcc00';
                                    }else {
                                        $color = 'color:#ccc';
                                    }
                                ?>
                            <li title="star_rating"
                            id="<?php echo e($pd_details->product_id); ?>-<?php echo e($i); ?>"
                            data-index="<?php echo e($i); ?>"
                            data-product_id="<?php echo e($pd_details->product_id); ?>"
                            data-rating="<?php echo e($rating); ?>"
                            class="rating"
                            style="cursor: pointer; <?php echo e($color); ?>; font-size:40px;font-weight:500">
                                &#9733;
                            </li>
    
                            <?php endfor; ?>
                        </ul>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div><!--/category-tab-->
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<div class="recommended_items"><!--recommended_items-->
    <h2 class="title text-center">Sản phẩm liên quan</h2>
    
    <div id="recommended-item-carousel" class="carousel slide" data-ride="carousel">
        <div class="carousel-inner">
            <div class="item active">	
                <?php $__currentLoopData = $related_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item => $related_pd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-sm-3 product-main">
                    <div class="product-image-wrapper">
                        <div class="single-products">
                            <div class="productinfo">
                                <form>
                                    <?php echo e(csrf_field()); ?>

                                    <input type="hidden" value="<?php echo e($related_pd->product_quantity); ?>" class="check_product_qty_<?php echo e($related_pd->product_id); ?>">
            
                                    <input type="hidden" value="<?php echo e($related_pd->product_id); ?>" class="cart_product_id_<?php echo e($related_pd->product_id); ?>">
                                    <input type="hidden" value="<?php echo e($related_pd->product_name); ?>" class="cart_product_name_<?php echo e($related_pd->product_id); ?>">
                                    <input type="hidden" value="<?php echo e($related_pd->product_img); ?>" class="cart_product_image_<?php echo e($related_pd->product_id); ?>">
                                    <input type="hidden" value="<?php echo e($related_pd->product_desc); ?>" class="cart_product_desc_<?php echo e($related_pd->product_id); ?>">
                                    <input type="hidden" value="<?php echo e($related_pd->product_price); ?>" class="cart_product_price_<?php echo e($related_pd->product_id); ?>">
                                    <input type="hidden" value="1" class="cart_product_qty_<?php echo e($related_pd->product_id); ?>">
            
            
                                    <a href="<?php echo e(URL::to('chi-tiet-san-pham/'.$related_pd->product_id)); ?>" class="link-product-details">
                                    </a>
                                    <img src="<?php echo e(URL::to('public/upload/product/'.$related_pd->product_img)); ?>" alt="" />
                                    <div class="product-info-details">
                                        <p><?php echo e($related_pd->product_name); ?></p>
                                        <div class="product-price-sold">
                                            <span class="product-price"><?php echo e(number_format($related_pd->product_price,0,',','.')); ?>.đ</span>
                                            <span class="product-sold">Đã bán 100</span>
                                        </div>
                                        <div class="product-rate-cart">
                                            <div class="product-rate">
                                                <img style="width:75%; margin-top:0" src="<?php echo e(asset('public/front-end/images/product-details/rating.png')); ?>" alt=""/>
                                                <span style="color: #ccc; margin-left:4px">10</span>
                                            </div>
                                            <button type="button" class="btn btn-default add-to-cart" data-id_product="<?php echo e($related_pd->product_id); ?>" name="add-to-cart"><i class="fa-solid fa-cart-plus"></i></button>
                                        </div>
                                    </div>
                                </form>
                            </div>
            
                        </div>
                        <div class="choose">
                            <ul class="nav nav-pills nav-justified">
                                
                                <li><a href="#" ><i class="fa-regular fa-heart like-product"></i>Yêu thích</a></li>
                                <li><a href="#" class=""><i class="fa-solid fa-down-left-and-up-right-to-center" style="color: rgb(115, 115, 241)"></i>So sánh</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="items-overlay"></div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
            </div>
            
        </div>
   
            <a class="left recommended-item-control" href="#recommended-item-carousel" data-slide="prev">
            <i class="fa fa-angle-left"></i>
            </a>
            <a class="right recommended-item-control" href="#recommended-item-carousel" data-slide="next">
            <i class="fa fa-angle-right"></i>
            </a>			
    </div>
</div><!--/recommended_items-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\nien-luan-b1706621\resources\views/pages/product/show_details.blade.php ENDPATH**/ ?>