
<?php $__env->startSection('content'); ?>

<section id="cart_items">
    <div class="container">
        <div class="review-payment">
            <h2>Cảm ơn bạn đã đặt hàng tại shop chúng tôi</h2>
            <h3>Bạn có thể xem lại đơn đã đặt <a href="">tại đây</a></h3>
        </div>
        
    </div>
</section> 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\tieu-luan\resources\views/pages/checkout/handcash.blade.php ENDPATH**/ ?>